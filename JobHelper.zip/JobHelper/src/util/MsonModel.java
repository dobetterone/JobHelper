package util;


import java.util.ArrayList;
import java.util.List;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class MsonModel {
	int num;
	public MsonModel(int num) {
		this.num = num;
	}
	public List<VBox> createMasonModel(){
		List<VBox>msonList = new ArrayList<>();
		for(int i=1;i<=num;i++){
			VBox MsonVBox = new VBox();
			HBox hBoxBottom = new HBox();
			
			TextField textFieldModelName = new TextField();
			textFieldModelName.setPromptText("模块名");
			textFieldModelName.setPrefWidth(200);
			TextField textFieldModelAllScore = new TextField();
			textFieldModelAllScore.setPromptText("该模块分");
			textFieldModelAllScore.setMinWidth(0);
			textFieldModelAllScore.setPrefWidth(80);
			
			hBoxBottom.getChildren().add(textFieldModelName);
			hBoxBottom.getChildren().add(textFieldModelAllScore);
			hBoxBottom.setSpacing(10);
			hBoxBottom.setPadding(new Insets(10, 20, 10, 20));
			
			MsonVBox.getChildren().add(hBoxBottom);
			msonList.add(MsonVBox);
		}
		return msonList;
	}
}
