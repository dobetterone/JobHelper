package util.impl;


import util.DrawInterface;

public class DrawUtil implements DrawInterface {
	@Override
	public void addDrawFunc() throws Exception {
		// TODO Auto-generated method stub

	}
}
