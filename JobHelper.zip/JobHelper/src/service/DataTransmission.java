package service;
/***
 * 主界面与子界面之间controller之间的通信
 * @author 航航
 *
 */
public interface DataTransmission {
	public void trasportData() throws Exception;
}
