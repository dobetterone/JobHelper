package service.impl;

import java.util.List;

import service.ExchangeData;

public class ExchangeDataImpl implements ExchangeData {

	@Override
	public void exchange(int ModelNum, String ModelName, List<Integer> ModelAllScore, String gradeName, String className)
			throws Exception {
		
	}

}
