package service.impl;

import javafx.scene.layout.VBox;
import service.ChangeMainModel;

public class ChangeMainModelImpl implements ChangeMainModel {

	@Override
	public VBox createModel() throws Exception {
		return null;
	}
}
