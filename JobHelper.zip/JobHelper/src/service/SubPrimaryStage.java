package service;

import javafx.stage.Stage;

/***
 * 
 * @author 航航
 *
 */
public interface SubPrimaryStage {
	public void openPrimaryStage() throws Exception;
}	
