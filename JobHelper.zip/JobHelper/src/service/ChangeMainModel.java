package service;

import javafx.scene.layout.VBox;

public interface ChangeMainModel {
	public VBox createModel() throws Exception;
}
